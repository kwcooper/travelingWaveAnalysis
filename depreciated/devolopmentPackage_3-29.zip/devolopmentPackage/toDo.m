 
%1/20
% to do, look for variablility across recording
% slide the mean theta wave across the chuncks? 
% calculate corrolaton for each?

% still need to make the corolation plot yeah?

%2/8
% try different animals! 
%    something is wrong... why is rio's slopes positive
% add eeg to plotss
% figure out how robost regression works
% 